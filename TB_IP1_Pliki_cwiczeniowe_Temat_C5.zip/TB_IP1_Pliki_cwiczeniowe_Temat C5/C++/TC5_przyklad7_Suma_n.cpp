#include <iostream>
using namespace std;

int main()

{
	int i, a, suma, n;
	cout << "Ile liczb: ";
	cin >> n;
	suma = 0;
	for (i = 0; i < n; i++)
	{
		cout << "Podaj liczbe: ";
		cin >> a;
		suma = suma + a;
	}
	cout << "Suma wynosi: " << suma;
	
	return 0;
}




