#include <iostream>
using namespace std;

int main()
{
	int i, j, m, n;
	cout << "Podaj wymiary prostokata: ";
	cin >> m >> n;
	for (i = 0; i < n; i++ )
	{
		for (j = 0; j < m; j++)
			cout << "x";
		cout << endl;
	}
	return 0;
}



	
