n = int(input("Ile liczb: "))

suma = 0
for i in range(n):
    a = int(input("Wprowadź liczbę: "))
    suma = suma + a
print("Suma wynosi:", suma)


input("\n\nAby zakończyć, naciśnij Enter")




