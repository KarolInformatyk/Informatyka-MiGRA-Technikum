m = int(input("Podaj pierwszy wymiar prostokata: "))
n = int(input("Podaj pierwszy drugi prostokata: "))

for i in range(n):
    for j in range(m):
        print("x", end = "")
    print()



    


