x = int(input( "Podaj liczbe x: "))

if x >= 0:
    w = x
else:
    w = -x
print("Wartość bezwzględna |x| =", w)


input("\n\nAby zakończyć, naciśnij Enter")





