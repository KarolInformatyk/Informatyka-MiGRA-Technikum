pkt = int(input("Podaj liczbę punktów zdobytych przez klasę: "))
f = float(input("Podaj frekwencję klasy: "))
so = float(input("Podaj średnią ocen klasy: "))

if f > 94 and so >= 4.0:
    pkt = pkt + 20      
print("Aktualna liczba punktów wynosi: " , pkt)


input("\n\nAby zakończyć, naciśnij Enter") 


