#include <iostream>
using namespace std;
int main()
{
	int pkt;
	float f, so;

	cout << "Podaj liczbe punktow zdobytych przez klase: ";
	cin >> pkt;
	cout << "Podaj frekwencje klasy: ";
	cin >> f;
	cout << "Podaj srednia ocen klasy: ";
	cin >> so;
	if(f > 94 && so >= 4.0)
		pkt = pkt + 20;
    cout << "Aktualna liczba punktow wynosi: " << pkt;

	return 0;
}




