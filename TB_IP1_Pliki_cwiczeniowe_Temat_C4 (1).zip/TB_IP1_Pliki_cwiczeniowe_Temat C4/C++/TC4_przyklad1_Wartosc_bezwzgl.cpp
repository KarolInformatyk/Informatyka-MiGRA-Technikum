#include <iostream>
using namespace std;
int main()
{
	int x, w;
	cout << "Podaj liczbe x: ";
	cin >> x;
	if (x >= 0) 
		w = x; 
	else 
		w = -x;
	cout << "Wartosc bezwzgledna |x| = " << w;
	
	return 0;
}




